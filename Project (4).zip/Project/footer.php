


<div class="footer">
            <div class="fcontainer">
                <div class="frow">
                    <div class="footer-col">
                        <h4>Customer Care</h4>
                        <ul>
                            <li><a href="support.php">Help Center</a></li>
                            <li><a href="rating.php">Feedback</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                            <li><a href="login.php">LogIn</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Lanka Land</h4>
                        <ul>
                            <li><a href="#">About Lanka Land</a></li>
                            <li><a href="news.php">News</a></li>                           
                            <li><a href="privacypolicy.php">Privacy Policy</a></li>
                            <li><a href="t&c.php">Trems & Condition</a></li>
                        </ul>
                    </div> 
                     
                    <div class="footer-col">
                        <h4>Follow Us</h4>
                        <div class="social-link">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>  
                    <div class="footer-col">
                        <h4>Payement Method</h4>
                        <div class="payment-link">
                            <a ><i class="fa-brands fa-cc-visa"></i></a>
                            <a ><i class="fa-brands fa-cc-mastercard"></i></a>
                            <a ><i class="fa-sharp fa-solid fa-wallet"></i></a>
                        </div>
                    </div>      
                </div>
            </div>
        </div>
    </body>
	
	
   
 
</body>
</html>