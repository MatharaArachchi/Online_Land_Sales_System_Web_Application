<?php
    include_once 'header.php';
?>

<header>
        
		<nav class="navigation">
			<a href="home.php" class="active">Home</a>
			<a href="land.php" >Land</a>
			<a href="us.php">About Us</a>
			<a href="contact.php">Contact</a>
            <?php
            if( isset ($_SESSION["userid"] ))
                {
                  echo ' <a href="landTable.php">Edit Ad</a>';
                }
                else{
                    echo ' <a href="news.php">News</a>';
                    
                }
                ?>
            
            <?php
                if( isset ($_SESSION["userid"] ))
                {
                    echo ' <a href="addLand.php">Sell Your Land</a>';
                }
                else{
                    echo ' <a href="login.php">Sell Your Land</a>';
                    
                }
                ?>
            
        </nav> 
            
            <?php
                if( isset ($_SESSION["userid"] ))
                {
                    if(  ($_SESSION["userType"] ) === 'user'  )
                    {
                    echo '<span class="pro"><a href="userProfile.php">Hello '.$_SESSION["usersname"].'</a></span>';
                }
                else if  (  ($_SESSION["userType"] ) === 'admin'  )
                {
                    echo '<span class="pro"><a href="superadmin.html">Hello '.$_SESSION["userType"].'</a></span>'; 
                }
            }
                else{
                    echo '<button class="circle-button"><a href="login.php"><center><i class="far fa-user-circle" style="z-index: 9990; font-size:36px;color:white;"viewport></i></center></a></button>';
                    
                }
                
            ?>
            
    
</header>

<link rel="stylesheet" href="style\t&c.css">

<title>Edit Land</title>

</head>
<body>

  <div id="container">
    <h1>Terms and Conditions</h1>

    <p>Please read these Terms and Conditions ("Agreement") carefully before using the online land sale system ("System"). This Agreement sets forth the legally binding terms and conditions for your use of the System provided by [Company Name] ("Company").</p>

    <h3>Acceptance of Terms</h3>
    <p>By accessing or using the System, you agree to be bound by this Agreement and all applicable laws and regulations. If you do not agree with any part of this Agreement, you must not use the System.</p>

    <h3>Use of the System</h3>
    <h4>2.1 Eligibility</h4>
    <p>You must be at least 18 years old and have the legal capacity to enter into a binding agreement to use the System. By using the System, you represent and warrant that you meet these requirements.</p>

    <h4>2.2 Account Registration</h4>
    <p>To use certain features of the System, you may need to create an account. You agree to provide accurate, current, and complete information during the registration process and to keep your account information updated. You are responsible for maintaining the confidentiality of your account credentials and for any activities or actions taken under your account.</p>

    <h4>2.3 Prohibited Activities</h4>
    <p>You agree not to:</p>
    <ol type="a">
      <li>Use the System for any illegal or unauthorized purpose;</li>
      <li>Violate any applicable laws, regulations, or third-party rights;</li>
      <li>Attempt to gain unauthorized access to the System or interfere with its operation or security;</li>
      <li>Engage in any fraudulent or deceptive activities;</li>
      <li>Use the System to transmit any viruses, worms, or other malicious code.</li>
    </ol>

    <h3>Land Sale Listings</h3>
    <h4>3.1 Listing Information</h4>
    <p>You are solely responsible for the accuracy and completeness of any land sale listings you submit through the System. The information provided must not be misleading, false, or violate any applicable laws or regulations.</p>

    <h4>3.2 Intellectual Property Rights</h4>
    <p>By submitting land sale listings through the System, you represent and warrant that you have the necessary rights and permissions to use and display any intellectual property included in the listings. The Company does not claim ownership of your intellectual property.</p>

    <h4>3.3 Verification</h4>
    <p>The Company reserves the right to verify the accuracy of the land sale listings and may request additional information or documentation from you to validate the details provided.</p>

    <h3>Buying and Selling Land</h3>
    <h4>4.1 Transaction Parties</h4>
    <p>Buyers and sellers are solely responsible for negotiating and entering into agreements for the purchase and sale of land. The Company is not a party to these transactions and does not guarantee the quality, legality, or suitability of any land listed on the System.</p>

    <h4>4.2 Disputes</h4>
    <p>Any disputes or issues arising from land transactions conducted through the System should be resolved directly between the involved parties. The Company does not provide mediation, arbitration, or legal services for such disputes.</p>

    <h3>Payment and Fees</h3>
    <h4>5.1 Payment Processing</h4>
    <p>The System may provide payment processing services for land transactions. You agree to comply with the payment terms and conditions specified by the Company or its authorized payment processor.</p>

    <h4>5.2 Fees</h4>
    <p>The Company may charge fees for the use of certain features or services provided by the System. Any applicable fees will be clearly communicated to you, and you agree to pay them as required.</p>

    <h3>Privacy</h3>
    <p>Your privacy is important to us. Please review our <a href="privacy.html">Privacy Policy</a>, which explains how we collect, use, and disclose your information when you use the System.</p>

    <h3>Termination</h3>
    <p>The Company reserves the right, in its sole discretion, to suspend or terminate your access to the System at any time and for any reason, without notice or liability.</p>

    <h3>Limitation of Liability</h3>
    <p>To the fullest extent permitted by law, the Company shall not be liable for any indirect, incidental, consequential, or punitive damages arising out of or relating to the use of the System.</p>

    <div class="accept-decline">
      <label for="accept-checkbox">I have read and agree to the Terms and Conditions:</label>
      <input type="checkbox" id="accept-checkbox">
      <label for="decline-checkbox">I do not agree to the Terms and Conditions:</label>
      <input type="checkbox" id="decline-checkbox">
    </div>

    <button type="button" >Continue</button>
  </div>

  


  <?php
    include_once 'footer.php';
?>
