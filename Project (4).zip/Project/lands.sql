-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2023 at 12:39 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lands`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Feedback_ID` int(12) NOT NULL,
  `userId` int(12) NOT NULL,
  `rating` int(5) NOT NULL,
  `Feedback` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Feedback_ID`, `userId`, `rating`, `Feedback`) VALUES
(3, 5, 5, 'sdfghjkjhgfdsdfghjhgfdsasdfgh');

-- --------------------------------------------------------

--
-- Table structure for table `lands`
--

CREATE TABLE `lands` (
  `usersId` int(12) NOT NULL,
  `landID` int(12) NOT NULL,
  `Sname` varchar(32) NOT NULL,
  `Sphone` int(10) NOT NULL,
  `email` varchar(32) NOT NULL,
  `Saddress` varchar(32) NOT NULL,
  `city` varchar(32) NOT NULL,
  `price` int(32) NOT NULL,
  `size` float NOT NULL,
  `photo` longblob NOT NULL,
  `ldescription` varchar(128) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `FullName` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(20) NOT NULL,
  `State` int(20) NOT NULL,
  `ZipCode` varchar(10) NOT NULL,
  `CardNumber` int(16) NOT NULL,
  `Month` int(2) NOT NULL,
  `ExYear` int(4) NOT NULL,
  `CVV` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='       ';

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`FullName`, `Email`, `Address`, `City`, `State`, `ZipCode`, `CardNumber`, `Month`, `ExYear`, `CVV`) VALUES
('dinusha', 'dinusha@gmail.com', '', '', 0, '0', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `usersId` int(12) NOT NULL,
  `usersName` varchar(32) NOT NULL,
  `usersEmail` varchar(32) NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `phone` int(10) NOT NULL,
  `address` varchar(128) NOT NULL,
  `usersUid` varchar(32) NOT NULL,
  `usersPwd` varchar(128) NOT NULL,
  `userType` varchar(12) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usersId`, `usersName`, `usersEmail`, `NIC`, `phone`, `address`, `usersUid`, `usersPwd`, `userType`) VALUES
(1, 'admin', 'admin@gamil.com', '200158460254', 6666, '', 'admin                ', '$2y$10$BbMj6WTH/qzeFA8G09UT3ulizHkg6qAQB3S/XP1b5HRFhtSAHvsK6', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Feedback_ID`);

--
-- Indexes for table `lands`
--
ALTER TABLE `lands`
  ADD PRIMARY KEY (`landID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usersUid`),
  ADD UNIQUE KEY `usersId` (`usersId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Feedback_ID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lands`
--
ALTER TABLE `lands`
  MODIFY `landID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `usersId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
