<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi" />
	<link rel="icon" href="./src/lo.png">
    <link rel="stylesheet" href="Template.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="SignUp/signup.css">
    <?php
    session_start();
?>
    	
<link rel="stylesheet" href="style\header.css">

<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>

<a href="#srce" class="logo"  ><img src ="src\logo.png" alt="Logo" width="300px" height="150px" ></a>

